package com.demo;

import java.io.Serializable;

public class ClothBeanMaster implements Serializable {
    int favouriteId;
    int shirtId;
    int pantId;
    String name;


    public int getFavouriteId() {
        return favouriteId;
    }

    public void setFavouriteId(int favouriteId) {
        this.favouriteId = favouriteId;
    }

    public int getShirtId() {
        return shirtId;
    }

    public void setShirtId(int shirtId) {
        this.shirtId = shirtId;
    }

    public int getPantId() {
        return pantId;
    }

    public void setPantId(int pantId) {
        this.pantId = pantId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "ClothBeanMaster{" +
                "favouriteId=" + favouriteId +
                ", shirtId=" + shirtId +
                ", pantId=" + pantId +
                ", name='" + name + '\'' +
                '}';
    }
}
