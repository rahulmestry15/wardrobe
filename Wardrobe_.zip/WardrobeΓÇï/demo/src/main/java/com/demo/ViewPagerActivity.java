package com.demo;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.directionalviewpager.demo.R;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.DirectionalViewPager;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import com.bumptech.glide.Glide;
import com.theartofdev.edmodo.cropper.CropImage;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ViewPagerActivity extends AppCompatActivity {

    private DirectionalViewPager pager, pager2;
    Adapter a, b;
    private final int MY_PERMISSIONS_REQUEST = 10;
    String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
    static final int WRITE_REQUEST_CODE = 101;
    public Uri imageUri;
    public SQLManager sqlManager;
    public static int addImage = 0;
    public List<ClothBeanMaster> shirtList = new ArrayList<>();
    public List<ClothBeanMaster> pantList = new ArrayList<>();
    public List<ClothBeanMaster> favList = new ArrayList<>();
    public ImageView addFav;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Toolbar toolbar = findViewById(R.id.toolbar);
        pager = findViewById(R.id.pager);
        pager2 = findViewById(R.id.pager2);
        sqlManager = new SQLManager(this);
        addFav = findViewById(R.id.add_fav);

        a = new Adapter( shirtList, ViewPagerActivity.this);
        b = new Adapter( pantList, ViewPagerActivity.this);

        //  setSupportActionBar(toolbar);
        pager.setAdapter(a);
        pager2.setAdapter(b);
        pager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {


            @Override
            public void onPageScrolled(int i, float v, int i1) {

            }

            @Override
            public void onPageSelected(int i) {
                addFav.setBackgroundResource(R.drawable.ic_heart);

       //         Toast.makeText(ViewPagerActivity.this, "pager1 " + i, Toast.LENGTH_SHORT).show();
                checkFav();
            }

            @Override
            public void onPageScrollStateChanged(int i) {
            }
        });
        pager2.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {


            @Override
            public void onPageScrolled(int i, float v, int i1) {

            }

            @Override
            public void onPageSelected(int i) {
                addFav.setBackgroundResource(R.drawable.ic_heart);
                checkFav();
//                Toast.makeText(ViewPagerActivity.this, "pager2 " + i, Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onPageScrollStateChanged(int i) {
            }
        });

        findViewById(R.id.reload).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pager.setCurrentItem(new Random().nextInt(shirtList.size()));
                pager2.setCurrentItem(new Random().nextInt(pantList.size()));
              //  getList();
                checkFav();
            //    Toast.makeText(ViewPagerActivity.this, "innnn", Toast.LENGTH_SHORT).show();
            }
        });
        findViewById(R.id.add1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addImage = 1;
                CropImage.activity(imageUri)
                        .start(ViewPagerActivity.this);
                //getList();

            }
        });
        findViewById(R.id.add2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addImage = 2;
                CropImage.activity(imageUri)
                        .start(ViewPagerActivity.this);
            }
        });
        findViewById(R.id.add_fav).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClothBeanMaster clothBeanMaster = new ClothBeanMaster();
                clothBeanMaster.setShirtId(shirtList.get(pager.getCurrentItem()).getShirtId());
                clothBeanMaster.setPantId((pantList.get(pager2.getCurrentItem()).getPantId()));
                String s = sqlManager.saveFavouiteApi(clothBeanMaster);
                if(s.equalsIgnoreCase("success")) {
                    Toast.makeText(ViewPagerActivity.this, "set successfully", Toast.LENGTH_SHORT).show();
                }
                //checkFav();
                getFavList();
            }
        });

        requestAppPermissions(this);
        getFavList();
     //   checkFav();
    }

    class Adapter extends PagerAdapter {
        //int a = 0;
        public List<ClothBeanMaster> clothList = new ArrayList<>();
        public Activity activity;

        @Override
        public int getCount() {
            return clothList.size();
        }

        public Adapter( List<ClothBeanMaster> clothBeanMasters, Activity activity) {
        //    this.a = a;
            this.activity = activity;
            this.clothList = clothBeanMasters;
        }

        @NonNull
        @Override
        public Object instantiateItem(@NonNull ViewGroup container, int position) {
            ImageView imageView = new ImageView(container.getContext());
            //imageView.setForegroundGravity(Gravity.CENTER);
//            text.setTextSize(64);
            //imageView.setText("" + position);
//            imageView.setImageUriAsync(resultUri);

            File imgFile = new File("data/user/0/android.support.directionalviewpager.demo/cache/" + clothList.get(position).getName());

            if (imgFile.exists()) {
                Bitmap myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
                imageView.setImageBitmap(myBitmap);

            }
            //  Glide.with(activity).load("data/user/0/android.support.directionalviewpager.demo/cache/" + clothList.get(position).getName()).into(imageView);
            container.addView(imageView);
            return imageView;
        }

        @Override
        public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
            View view = (View) object;
            container.removeView(view);
        }

        @Override
        public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
            return view == object;
        }

        public void reload( List<ClothBeanMaster> clothBeanMasters) {
            //this.a = a;
            this.clothList = clothBeanMasters;
            notifyDataSetChanged();

        }

    }


    private void requestAppPermissions(Activity currentActivity) {

        List<String> listpermissions = new ArrayList<>();
        if (ContextCompat.checkSelfPermission(currentActivity, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            listpermissions.add(Manifest.permission.CAMERA);
        }
        if (ContextCompat.checkSelfPermission(currentActivity, Manifest.permission.INTERNET) != PackageManager.PERMISSION_GRANTED) {
            listpermissions.add(Manifest.permission.INTERNET);
        }
        if (ContextCompat.checkSelfPermission(currentActivity, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            listpermissions.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (ContextCompat.checkSelfPermission(currentActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            listpermissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }

        if (ContextCompat.checkSelfPermission(currentActivity, Manifest.permission.ACCESS_NETWORK_STATE) != PackageManager.PERMISSION_GRANTED) {
            listpermissions.add(Manifest.permission.ACCESS_NETWORK_STATE);
        }
        if (ContextCompat.checkSelfPermission(currentActivity, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            listpermissions.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }

        if (listpermissions.size() != 0) {

            ActivityCompat.requestPermissions(currentActivity, listpermissions.toArray(new String[0]), MY_PERMISSIONS_REQUEST);
        }
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {
                Uri resultUri = result.getUri();

                File file = new File(resultUri.getPath());
                String nameFile = getFileName(resultUri.getPath());
                long fileSizeInBytes = file.length();
                long fileSizeInKB = fileSizeInBytes / 1024;
                long fileSizeInMB = fileSizeInKB / 1024;

///data/user/0/android.support.directionalviewpager.demo/cache/cropped-2071713554.jpg
                ClothBeanMaster clothBeanMaster = new ClothBeanMaster();
                clothBeanMaster.setName("" + getFileName(resultUri.getPath()));

                if (addImage == 1) {
                    sqlManager.saveShirtApi(clothBeanMaster);
                } else if (addImage == 2) {
                    sqlManager.savePantApi(clothBeanMaster);
                }
                Toast.makeText(this, "Success", Toast.LENGTH_SHORT).show();
                getFavList();

            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Exception error = result.getError();
            }
        }
    }

    public static String getFileName(String fileName) {
        if (fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0)
            return fileName.substring(fileName.lastIndexOf("/") + 1);

        else return "";
    }

    public void getFavList() {
        List<ClothBeanMaster> favouriteList = sqlManager.getFavList();
        favList.clear();
        favList.addAll(favouriteList);
        //a.setc(1);
        getList();

    }

    public void getList() {

        List<ClothBeanMaster> shirtList1 = sqlManager.getShirtMasterList();

        shirtList.clear();
        shirtList.addAll(shirtList1);
        //a.reload(shirtList);
        //pager.setCurrentItem(shirtCurrentId);


        List<ClothBeanMaster> pantList1 = sqlManager.getPantMasterList();
        pantList.clear();
        pantList.addAll(pantList1);
      //  b.reload( pantList);
        //pager2.setCurrentItem(pantCurrentId);
        a = new Adapter( shirtList, ViewPagerActivity.this);
        b = new Adapter( pantList, ViewPagerActivity.this);

        //  setSupportActionBar(toolbar);
        pager.setAdapter(a);
        pager2.setAdapter(b);

        checkFav();

    }

    public void checkFav() {
        for (ClothBeanMaster clothBeanMaster : favList) {
            if (clothBeanMaster.getShirtId() == shirtList.get(pager.getCurrentItem()).getShirtId() && clothBeanMaster.getPantId() == pantList.get(pager2.getCurrentItem()).getPantId()) {
                addFav.setBackgroundResource(R.drawable.ic_like);
            }
        }

    }


}
