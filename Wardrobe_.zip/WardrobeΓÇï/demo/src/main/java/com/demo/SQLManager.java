package com.demo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;

public class SQLManager extends SQLiteOpenHelper {
    public Context context;



    String shirt = " CREATE TABLE shirt ( "
            + "   shirt_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL , "
            + "   name TEXT  "
            + " )  ";


    String pant = " CREATE TABLE pant ( "
            + "   pant_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL , "
            + "   name TEXT  "
            + " )  ";


    String favourite = " CREATE TABLE favourite ( "
            + "   favourite_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL , "
            + "   shirt_id TEXT,  "
            + "   pant_id TEXT  "
            + " )  ";

    public SQLManager(Context context) {
        super(context, "DKTest.db", null, 1);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {



        try {
            db.execSQL(shirt);
        } catch (Exception e) {
            e.printStackTrace();
        }




        try {
            db.execSQL(pant);
        } catch (Exception e) {
            e.printStackTrace();
        }


        try {
            db.execSQL(favourite);
        } catch (Exception e) {
            e.printStackTrace();
        }


    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

    }

    /////////////////////////////////   API   /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public String saveShirtApi(ClothBeanMaster clothBeanMaster) {
        String responseMsg = "unsuccess";
        try {
            if (clothBeanMaster.getShirtId() == 0) {
                int lastestId = saveShirt(clothBeanMaster);
            } else {
                updateShirt(clothBeanMaster);
            }
            responseMsg = "success";
        } catch (Exception e) {
            e.printStackTrace();
            responseMsg = "unsuccess";
        }
        return responseMsg;
    }
    public String savePantApi(ClothBeanMaster clothBeanMaster) {
        String responseMsg = "unsuccess";
        try {
            if (clothBeanMaster.getShirtId() == 0) {
                int lastestId = savePant(clothBeanMaster);
            } else {
                updatePant(clothBeanMaster);
            }
            responseMsg = "success";
        } catch (Exception e) {
            e.printStackTrace();
            responseMsg = "unsuccess";
        }
        return responseMsg;
    }
    public String saveFavouiteApi(ClothBeanMaster clothBeanMaster) {
        String responseMsg = "unsuccess";
        try {

                int lastestId = saveFavouite(clothBeanMaster);

            responseMsg = "success";
        } catch (Exception e) {
            e.printStackTrace();
            responseMsg = "unsuccess";
        }
        return responseMsg;
    }
//
//    public String deleteStageApi(StatusMaster statusMaster) {
//        String responseMsg = "unsuccess";
//        try {
//            deleteById("stage_master", "stage_master_id", statusMaster.getStatusMasteId());
//            responseMsg = "success";
//        } catch (Exception e) {
//            e.printStackTrace();
//            responseMsg = "unsuccess";
//        }
//        return responseMsg;
//    }


    public List<ClothBeanMaster> getShirtMasterList() {
        List<ClothBeanMaster> clothBeanMasters = new ArrayList<ClothBeanMaster>();
        try {
            String query = "SELECT shirt_id,name FROM shirt  order by 1 desc ";
            String args[] = {};


            SQLiteDatabase db = getReadableDatabase();
            Cursor rs = db.rawQuery(query, args);
            if (rs.moveToFirst()) {
                do {
                    ClothBeanMaster clothBeanMaster = new ClothBeanMaster();
                    clothBeanMaster.setShirtId(rs.getInt(0));
                    clothBeanMaster.setName(rs.getString(1));
                    clothBeanMasters.add(clothBeanMaster);
                } while (rs.moveToNext());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return clothBeanMasters;
    }


    public List<ClothBeanMaster> getPantMasterList() {
        List<ClothBeanMaster> clothBeanMasters = new ArrayList<ClothBeanMaster>();
        try {
            String query = "SELECT pant_id,name FROM pant  order by 1 desc ";
            String args[] = {};


            SQLiteDatabase db = getReadableDatabase();
            Cursor rs = db.rawQuery(query, args);
            if (rs.moveToFirst()) {
                do {
                    ClothBeanMaster clothBeanMaster = new ClothBeanMaster();
                    clothBeanMaster.setPantId(rs.getInt(0));
                    clothBeanMaster.setName(rs.getString(1));
                    clothBeanMasters.add(clothBeanMaster);
                } while (rs.moveToNext());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return clothBeanMasters;
    }

    public List<ClothBeanMaster> getFavList() {
        List<ClothBeanMaster> clothBeanMasters = new ArrayList<ClothBeanMaster>();
        try {
            String query = "SELECT favourite_id,pant_id,shirt_id FROM favourite  order by 1 desc ";
            String args[] = {};


            SQLiteDatabase db = getReadableDatabase();
            Cursor rs = db.rawQuery(query, args);
            if (rs.moveToFirst()) {
                do {
                    ClothBeanMaster clothBeanMaster = new ClothBeanMaster();
                    clothBeanMaster.setFavouriteId(0);
                    clothBeanMaster.setPantId(rs.getInt(1));
                    clothBeanMaster.setShirtId(rs.getInt(2));
                    clothBeanMasters.add(clothBeanMaster);
                } while (rs.moveToNext());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return clothBeanMasters;
    }


    public int saveShirt(ClothBeanMaster clothBeanMaster) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", clothBeanMaster.getName());
        int a = (int) db.insert("shirt", null, cv);
        return a;
    }

    public int updateShirt(ClothBeanMaster clothBeanMaster) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", clothBeanMaster.getName());
        int a = (int) db.update("shirt", cv, " shirt_id = ?", new String[]{"" + clothBeanMaster.getShirtId()});
        return a;
    }


    public int savePant(ClothBeanMaster clothBeanMaster) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", clothBeanMaster.getName());
        int a = (int) db.insert("pant", null, cv);
        return a;
    }

    public int updatePant(ClothBeanMaster clothBeanMaster) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", clothBeanMaster.getName());
        int a = (int) db.update("pant", cv, " pant_id = ?", new String[]{"" + clothBeanMaster.getPantId()});
        return a;
    }

    public int saveFavouite(ClothBeanMaster clothBeanMaster) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("shirt_id", clothBeanMaster.getShirtId());
        cv.put("pant_id", clothBeanMaster.getPantId());
        int a = (int) db.insert("favourite", null, cv);
        return a;
    }


}
